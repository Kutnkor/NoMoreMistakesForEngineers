# CIRCUIT FORGE — Breadboard Lab v5

5 Eylül 2026. `/breadboard`, mevcut Filtre AI uygulamasından seçili R/C değerlerini alabilir. Bu modül fiziksel bağlantı düzenleyicisidir; yeni bir AI modeli veya analog frekans çözücüsü değildir. AI tasarım ve araştırma motorları `/filter` ve `/lab` içinde korunur.

## Elektriksel model

- 63 sütun × 10 sinyal deliği, 4 ray × 50 delik: toplam 830.
- A–E ve F–J her sütunda iki bağımsız bakır grup. Karşılıklı E/F delikleri 7,62 mm, normal aralık 2,54 mm.
- Dört güç rayının HER BİRİ ortadan bölünür: 126 sinyal grubu + 8 ray segmenti = 134 temel düğüm. Kaynak istemindeki 126+4 toplamı bu bölünme tanımıyla tutarsız olduğu için 134 kullanıldı.
- TL072 üstten görünüm: 1–4 bir tarafta, 8–5 karşısında; DIP-8 kanal boyunca durur. 90 derece dönüş kanala oturmadığı için hata verir. 180 derece ters yerleşim doğru sütun sırası ve E/F yönüyle denetlenir.
- Direnç, kondansatör, bobin ve op-amp üzerinden doğrudan kısa devre varsayılmaz. Yalnız gerçek bakır gruplar, jumper uçları ve `wire` bileşeni union-find ile birleştirilir.
- Bu fiziksel grafikten çıkarılan bileşen-bacak bölümlemesi ayrı hedef grafiğiyle karşılaştırılır. Hedef net etiketleri fiziksel grafikte bağlantı üretmez. NC bacakları birbirinden bağımsızdır.
- VCC/GND/VEE sol girişleri, sağ süreklilik kontrol noktaları ve IN/OUT portları sabittir. Sağ nokta ikinci besleme girişi değildir. Ortadaki köprü eksikse ilgili ray için hata oluşur.

## Yerleştirme ve etkileşim

Deterministik yerleştirici önce DIP-8'i, sonra sinyal dağıtım sütunlarını ve 3–12 delik aralığındaki pasif bacakları yerleştirir. Her delikte tek bacak/jumper ucu, her grupta yönlendirme için boş delik bırakılır. Pasif gövde aralıkları aynı sırada çakışmayacak biçimde seçilir. Daha sonra gruplar jumperlarla bağlanır; sonuç bağımsız denetimden geçmeden otomatik yerleşim kabul edilmez.

2D SVG ile Three.js 0.185.1 sahnesi aynı milimetre koordinatlarını ve yerleşim verisini kullanır. 830 delik 3D'de InstancedMesh ile, yazılar tek doku atlasıyla çizilir. 2D delik katmanı memoize edilir. Sürükleme sırasında sadece taşınan model ve ona bağlı jumper uçları güncellenir; bırakınca ızgaraya oturtulur ve netlist tekrar çıkarılır. Gölge haritası yerleşim değişince yenilenir. Yavaş çizimde sürükleme çözünürlüğü uyarlanır, bırakınca tam çözünürlük geri gelir. Hızlı GPU tam ayrıntıyı korur.

Direnç bantları iki anlamlı basamak + çarpan + toleranstan hesaplanır; dört banda tam sığmayan değer uydurulmuş bantlarla yuvarlanmaz, değeri yazılır. Seramik/film kondansatör kodu pikofarad cinsinden hesaplanır. Elektrolitikte 1 pozitif, 2 negatif bacak; şerit negatif taraftadır. DIP-8 çentiği ve pin-1 noktası üstten görünümle eşleşir.

Öğrenme akışı boş tahta, parça tepsisi, adım ipucu ve 'Bu adımı uygula' düğmesini içerir. R döndürür, Delete/Backspace çıkarır, Ctrl/Cmd+Z geri alır. Elle jumper için iki boş deliğe tıklanır. Şema ile tahta parçalarının vurgusu çift yönlüdür; net vurgusu aynı elektriksel gruptaki delik ve kabloları gösterir. Düzenleme geçmişi 80 adımla sınırlıdır.

## Doğrulama

GitHub kopyasında `pnpm test`: 50 test (49 alan testi + 1 bağımsız statik sunucu testi); 16 test breadboard modelini kapsar. Beş örnek (Sallen–Key LP/HP, MFB BP, pasif RC, kaskad 4. derece) deterministik yerleştirme sonrası şemayla aynı bağlantı bölümlemesini verdi. Yanlış C2.2 → B bağlantısı, kopuk ray, kısa devre, çakışan delik, silme ve hatalı DIP ayak izi ayrı olumsuz testlerdir.

`tests/breadboard-browser.mjs` gerçek pointer hareketleri kullanır. Tarayıcı çalıştırması: Chromium 151.0.7922.34, 1280×1000 viewport, DPR 1. Apple M4 / ANGLE Metal ile 3D sürükleme 119 FPS ölçüldü. Bu değer tek makinedeki kısa etkileşim ölçümüdür; her cihazda 60 FPS garantisi değildir. GPU kapalı SwiftShader koşusunda geliştirme sırasında 33–47 FPS görüldü; yazılım çizimi ile GPU sonucu birbirine karıştırılmamalıdır. Son kayıt `breadboard-browser-validation.json` içindedir.

Tarayıcı kontrolü; 2D ve 3D pointer sürüklemesini, hatalı bacak tespitini, jumper takibini, iki görünümün aynı koordinatları korumasını, çift yönlü vurguyu, manuel kısa devreyi, 15 ipucuyla tamamlamayı, PNG indirmeyi ve 390 px karanlık temada sayfa taşmamasını kapsar. Ek masaüstü kontrollerinde R/Delete/Ctrl+Z, kamera sıfırlama ve iki PNG çıktısı doğrulandı. GitHub hazırlığında önceki testlerdeki beklenmeyen Promise kontrolleri ve uygulama lint bulguları düzeltildi. `pnpm lint` uygulama, alan kodu, hook, betik ve testleri kapsar; üçüncü taraf `components/ui/` şablon katmanı lint dışında, TypeScript kapsamındadır. Önceki Site sürümünün tüm-depo lint sonucu bu GitHub hazırlığından ayrıdır.

Beş kurulum kılavuzu gerçek Chromium yazdırma motoruyla PDF'ye çevrildi. pypdf ile her birinde 1 sayfa olduğu doğrulandı; Poppler PNG çıktılarında yazı, bağlantı listesi ve tahta görünümü görsel olarak incelendi. Kılavuz arayüz içinde önizlenir; yazdır/PDF ve bağımsız HTML indirme desteklenir.

## Tekrar çalıştırma

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm test:bundle
# Ayrı kurulmuş Playwright ile; GPU seçeneği macOS'ta Metal kullanır.
CF_TEST_GPU=1 node tests/breadboard-browser.mjs /absolute/test-output-directory
```

Playwright proje çalışma zamanı bağımlılığı değildir. `PLAYWRIGHT_MODULE` kurulu bir Playwright paketini, `PLAYWRIGHT_BROWSERS_PATH` test tarayıcısını, `BASE_URL` yalnız localhost uygulama adresini seçebilir. Test ayrı, boş bir tarayıcı profili kullanır; kullanıcının normal tarayıcı oturumunu kullanmaz.

## Kapsam

Netlist en fazla 32 bileşen/20 tanımlı net kabul eder; yerleştirici en fazla dört DIP-8 ve ayrılan sinyal dağıtım sütunlarına sığan tasarımlarla sınırlıdır. Sığmayan devre açık hata verir. Tam bir genel amaçlı PCB yönlendiricisi değildir. Bağlantı eşleşmesi, devrenin tüm frekanslarda veya gerçek donanımda doğru çalıştığını ispatlamaz. Özellikle örnekteki kullanılmayan TL072 kanalı NC korunmuştur; fiziksel kullanım için sonlandırma ve besleme bypass'ı gerekir. Donanım kurulumu yapılmadı.

JSON yükleme devre tanımını alır; yerleşim oturum belleğindedir. Netlist/yerleşim dışa aktarımı denetim kaydı içerir. İki ray yarısını gerçekten birleştiren köprüler gereklidir; gerçek üretici breadboard'larında ray bölünmesi değişebileceğinden fiziksel düzen ayrıca kontrol edilir.

## Birincil kaynaklar

- [TI TL072 veri sayfası](https://www.ti.com/lit/ds/symlink/tl072.pdf)
- [TI Sallen–Key alçak geçiren](https://www.ti.com/tool/CIRCUIT060054)
- [TI Sallen–Key yüksek geçiren](https://www.ti.com/tool/CIRCUIT060053)
- [TI MFB bant geçiren tasarım kaynakları](https://www.ti.com/tool/CIRCUIT060055)
- [Three.js InstancedMesh](https://threejs.org/docs/#api/en/objects/InstancedMesh)
- [Three.js OrbitControls](https://threejs.org/docs/#examples/en/controls/OrbitControls)
- [Playwright pointer API](https://playwright.dev/docs/api/class-mouse)
- [Chromium headless GPU koşulları](https://chromium.googlesource.com/chromium/src/+/HEAD/docs/gpu/using-gpu-hardware-in-headless-chrome.md)
