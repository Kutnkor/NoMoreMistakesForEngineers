# CIRCUIT FORGE v4 — yeni laboratuvarın yöntemleri

Tarih: 2026-09-05. Yazılım araştırma prototipi; fiziksel donanım veya uçuş verisi kullanılmadı. Kullanıcının eski NPZ paketinden model eğitilmedi. Yeni arıza verisi bu depodaki bağımsız tek topolojili motordan üretildi.

## Sonlu op-amp modeli

Topoloji: R1 giriş–a, R2 a–b, C1 a–çıkış, C2 b–toprak. Op-amp b düğümünü izleyen birim kazançlı tampon; giriş empedansı sonsuz, çıkış empedansı sıfır. Açık çevrim `A(s)=A0/(1+s*A0/(2π*GBW))`. GBW, tek kutuplu açık çevrim modelinin kazanç–bant genişliği parametresidir.

`a=C2(R1+R2)`, `b=R1R2C1C2`, `k=R1C1`, `u=1/A0`, `t=1/(2π*GBW)` tanımlarıyla:

`H(s)=1/[d0+d1*s+d2*s²+d3*s³]`

- `d0=1+u`
- `d1=(1+u)*a+t+u*k`
- `d2=(1+u)*b+t*(a+k)`
- `d3=t*b`

Geçirme bandında en büyük mutlak dB sapması, durdurma bandında en düşük bastırma hesaplanır. Genlik paydasının `x=ω²` cinsinden türevi ikinci derece polinomdur; tüm pozitif kökler kontrol edilir. Dolayısıyla dar bir rezonansı yalnız grafik örnekleme aralığına güvenerek atlamayız.

`tests/lab.test.ts` bağımsız üç düğümlü kompleks KCL çözümünü 800 noktada karşılaştırır. `scripts/validate-ngspice.ts` 30 devrede 401'er frekans için gerçek ngspice 47 çalıştırır. Sonuç: 12.030 noktada en büyük bağıl kompleks fark 2,16×10⁻¹⁴; rapor `ngspice-validation.json`. Bu, aynı doğrusal modelin uygulama doğrulamasıdır. Doyum, slew rate, gürültü, ESR, sonlu çıkış empedansı, besleme ve sıcaklık etkileri eklenmedi.

Varsayılan A0=100 dB ve GBW=10 MHz, Claude dökümündeki parametrelerle eşleşir. Güncel Claude kaynak arşivi henüz alınmadığı için 13 topolojili motorun entegre edildiği iddia edilmez. `/filter` mevcut ideal motoru korur; `/lab` sonlu motoru kullanır.

## Bütçeyi yöneten AI

Her koşulda sekiz ortak, tekrarsız E24 başlangıç devresi bulunur. R 1–100 kΩ ve C 1–100 nF aralıklarında log uzayı kullanılır. Toleranslar bağımsız uniform R/C sapmalarıdır. Tam değerlendirme 48 ortak eğitim çekilişidir; skor, en büyük normalize bant ihlalinin nearest-rank %95 yüzdeliğidir. Daha düşük skor daha iyidir.

Yeni yöntemde ucuz tarama aynı 48 çekilişin ilk sekizini kullanır. Dört log-R/C koordinatına `tanh(ucuz skor)` ekleyen GP, `asinh(tam skor)` tahminini öğrenir. Beklenen iyileşme 0,006'yı aşarsa veya bekleyen aday havuzu 24'e ulaşırsa uygun aday ayrıntılı analize yükseltilir. Sekiz sonuç önbellekten kullanılır; yalnız 40 yeni çekiliş hesaplanır. Kısmi taramalar kazanan seçilemez. Bu, öğrenilmiş vekil modelle deney bütçesi tahsisidir; pekiştirmeli öğrenme olarak sunulmaz.

Taban yöntemler: mevcut dört boyutlu GP/EI ve log-uniform rastgele arama. Üçü de aynı başlangıçları, toleransları ve 768/1536/3072 adet AC devre gerçekleşmesi bütçesini kullanır. Bir AC gerçekleşmesi, bir devrenin tüm bant metriklerinin hesaplanmasıdır; farklı motorlarda eşit CPU süresi anlamına gelmez. Yöntem duvar saati süresi ayrıca kaydedilir. Kazananlar dondurulduktan sonra yöntem başına 1.024 bağımsız çekiliş yapılır. Bu 3.072 test hesabı arama bütçesinin dışındadır.

Önceden belirlenmiş 0–9 tohumları, üç frekans koşulu, 1.536 bütçe ve A0=100 dB/GBW=1 MHz ile 30 deney çalıştırıldı. `budget-benchmark.json` bütün aday geçmişlerini korur:

| Geçirme / durdurma | Bütçe yöneten AI | Standart GP | Rastgele |
|---|---:|---:|---:|
| 100 / 500 Hz | %10,0 | %0,0 | %0,0 |
| 1.000 / 5.000 Hz | %27,5 | %39,3 | %23,2 |
| 10.000 / 50.000 Hz | %39,7 | %50,5 | %39,1 |

Değerler 10 tohumdaki ortalama bağımsız tolerans verimidir. Genel üstünlük sonucu çıkmaz. Bu rapordan sonra ayarlanacak yöntemler, yeni ayrılmış hedefler ve tohumlarla sınanmalıdır. Bir sonraki araştırma: ucuz taramanın verdiği bilgi ve GP maliyeti arasındaki kazancı, eşit duvar saati bütçesinde ve ablation deneyleriyle ölçmek.

## Eğitilmiş arıza modeli

Altı sınıf: sağlıklı, C1 kayması, C2 kayması, C1 açık, R1 açık, R2 kısa. Kayma çarpanı 0,35–0,70 veya 1,40–2,00; C1 açık 1 fF artık kapasite, R1 açık 1 GΩ, R2 kısa 0,1 Ω ile temsil edilir. Aynı anda tek arıza vardır.

Nominal devre ve op-amp parametreleri bilinir. Girişe göre ölçülmüş 12 frekanstaki genlik/faz yanıtının nominalden farkları kullanılır: 24 giriş → 32 tanh birimi → altı softmax çıkışı. Frekanslar nominal f0'ın sabit katlarıdır. Arıza etiketi modelin girişinde yoktur.

- 800 farklı eğitim devresi, 9.600 ölçüm.
- 200 farklı doğrulama devresi, 1.200 ölçüm.
- 200 farklı test devresi, 1.200 ölçüm.
- Devre R/C grupları üç küme arasında tamamen ayrıdır.
- R ±%1, C ±%5 uniform; ölçüm gürültüsü genlikte 0,15 dB ve fazda 1° Gaussian standart sapma.
- Eğitim alanı: R 1–100 kΩ; C 1–100 nF; A0 80–120 dB; GBW 100 kHz–100 MHz.
- Sadece eğitim kümesiyle standartlaştırma. NumPy ile Adam, 250 epoch; en düşük doğrulama cross-entropy checkpointi (235) seçildi. Ardından test bir kez değerlendirildi.
- Önceden sabit 0,60 softmax skoru altında sonuç belirsiz bırakılır. Skorlar kalibre edilmiş olasılık değildir.

Sonuç: en yüksek skorlu sınıf %98 doğru; belirsizleri yanlış sayınca %97,5; 14 belirsiz. Sağlıklı 200 ölçümde 0 yanlış alarm, arızalı 1.000 ölçümde 2 kaçırılan arıza. Sıfır gözlenen yanlış alarm, gelecekte sıfır hata garantisi değildir. Çoklu arıza, farklı gürültü, bilinmeyen giriş, topoloji ve gerçek donanım genellemesi doğrulanmadı.

`generate-fault-data.ts` ve `train-fault-model.py` süreci tekrar üretir. Eğitim betiği veri ve grup hashlerini, model SHA-256'sını ve bağımsız NumPy tahmin fikstürünü `fault-model-report.json` içine yazar. Tarayıcı model hashini doğrular; TypeScript tahmini NumPy fikstürüyle 10⁻¹² içinde test edilir. Ham veri kullanıcı cihazından dışarı gönderilmez.

## Wokwi ve Arduino dışı kartlar

Beş kart eşlemesi: UNO R3, klasik Nano, Mega 2560, ESP32-DevKitC V4 (WROOM-32E) ve orijinal Raspberry Pi Pico (RP2040). Son ikisi kendi gerçek pin profilleriyle çalışır: ESP32 ADC1 ve GPIO adları, Pico GP adları ve GP4/5 I²C0. 5 V sonar gibi uygun olmayan eşlemeler engellenir.

On modül türü: LED, pot, buton, RGB LED (ortak katot), pasif buzzer, DHT22, DS18B20, MPU6050, SSD1306 ve HC-SR04. Kod, `diagram.json`, `libraries.txt`, fiziksel bağlantı notları ve manifest ZIP olarak dışa aktarılır. LED'ler için 1 kΩ seri direnç, tek hatlı sensörlere 4,7 kΩ pull-up eklenir. Wokwi OLED'i dört pinlidir; fiziksel Adafruit RESET pini simülasyonda -1 olur. Normal fiziksel kart sketchi RESET atamasını korur.

Dosyalar Wokwi'ye otomatik yüklenmez. CLI bağlantı denetimi ve Arduino CLI derlemesi, Wokwi bulutunda yürütme veya donanım testi yerine geçmez. Wokwi CLI 0.26.1, DS18B20 ve ESP32-DevKitC V4 için bilgi düzeyinde “undocumented type” mesajı veriyor; DS18B20 resmî parça belgesi ve ESP32 resmî board.json pin adları ayrıca kontrol edildi. Çıktılar ve çekirdek sürümleri `embedded-validation.json` içindedir.

## Sanal sensör sinyali

12 Hz, 0,6 g faydalı sinyale ikinci bir titreşim sinüsü eklenir. İki sinüsün sonlu motorla kararlı durum yanıtı hesaplanır, ardından örneklenir. RMS hata temiz sinyale göre zaman kaydırmadan hesaplandığı için hem gecikme hem genlik bozulmasını içerir. Gerçek uçuş/IMU verisi, geçici rejim ve ADC kuantalaması değildir.

## Birincil kaynaklar

- https://docs.wokwi.com/diagram-format
- https://docs.wokwi.com/getting-started/supported-hardware
- https://docs.wokwi.com/parts/wokwi-ds18b20
- https://docs.wokwi.com/parts/board-ssd1306
- https://docs.wokwi.com/guides/esp32
- https://github.com/wokwi/wokwi-boards/blob/main/boards/esp32-devkit-c-v4/board.json
- https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32/esp32-devkitc/user_guide.html
- https://www.raspberrypi.com/documentation/microcontrollers/pico-series.html
- https://arduino-pico.readthedocs.io/en/latest/wire.html
- https://ngspice.sourceforge.io/download.html
