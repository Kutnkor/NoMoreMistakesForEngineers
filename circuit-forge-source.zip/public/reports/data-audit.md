# CIRCUIT FORGE veri denetimi — 2026-09-05

**Güncellenmiş karar:** Paket araştırma için kullanılabilir bir başlangıç; doğrudan bağlamak için üretici motoruyla model ve veri sözleşmesini eşleştirmek gerekiyor. Sayısal dosyalar sağlam. Son Claude çalışma dökümü, üreticide sonlu op-amp bant genişliği kullanıldığını gösteriyor; mevcut sitedeki ideal modelle farklar yanlış etiket kanıtı değildir. Eksik üretim tanımları ve küçük bir eğitim–doğrulama devre örtüşmesi bulguları geçerliliğini koruyor. Bu denetimde model eğitilmedi; ham veriler uygulamaya bağlanmadı. NPZ dosyaları `allow_pickle=False` ile okundu; sağlanan kod/komutlar çalıştırılmadı.

## Son Claude çalışmasına göre model düzeltmesi

05 Eylül 2026'da Claude masaüstündeki **CIRCUIT FORGE / Circuit Forge elektronik optimizasyonu** konuşması ve kullanıcının paylaştığı çalışma dökümü incelendi. Döküm normal op-amp için tek kutuplu **A₀=100 dB (100.000), GBW=10 MHz** bildiriyor; analitik karşılaştırma testi ise ideale yakın farklı ayarlar kullanıyor.

Bu açıklamaya uygun, bağımsız türetilmiş modelde `G(s)=A(s)/(1+A(s))` ve `A(s)=A₀/(1+s/ωp)`, `ωp=2π·GBW/A₀` alınır:

`H(s)=G(s)/[1+s·C2·(R1+R2)+s²·R1·R2·C1·C2+s·R1·C1·(1−G(s))]`.

CSV satırı 1043'ün durdurma sınırındaki mutlak bastırması ideal modelde 9,8231 dB iken bu sonlu modelde yaklaşık **18,5044 dB** olur; 16,84 dB hedefini sağlar. Eğitim satırı 10674 için de ideal −0,1695 dB yerine yaklaşık **11,7010 dB** elde edilir ve 11,2582 dB sınırı sağlanır. Bunlar açıklanan modele göre bağımsız tanı hesaplarıdır; Claude'un kaynak kodu çalıştırılmış değildir. Tam bant marjları ve tüm veri etiketleri ayrıca doğrulanmalıdır.

**Aşağıdaki 448/18.075 sayısı ideal model ve belirtilen bant varsayımlarındaki uyumsuzluğu ölçer; doğrulanmış hatalı etiket sayısı değildir.** Önceki sayısal sonuçlar karşılaştırma kaydı olarak korunmuştur. Devre örtüşmesi, eksik MC etiketleri ve U manifestosu bulguları model farkından etkilenmez. Son çalışma ve entegrasyon incelemesi `claude-review.md` içindedir.

## Gerçekte bulunan şema

| Dosya | Satır | Diziler |
|---|---:|---|
| `cf_train.npz` | 121.006 | Aşağıdaki aynı 12 dizi |
| `cf_val.npz` | 15.948 | Aşağıdaki aynı 12 dizi |
| `cf_veri_ornegi.csv` | 3.000 | 26 sütun; fiziksel bileşenler ve Türkçe özellik adları |

NPZ içinde `fc`, `gain`, `ripple`, `stop_ratio`, `stop_db`, `bw`, `margin`, `p05_drop`, `has_mc`: `(N,) float32`; `U`: `(N,10) float32`; `topo_id`, `kind_id`: `(N,) int16`. NPZ'de R/C/L değerleri, topoloji adları veya kod çözme manifestosu yok. `U` topolojiye göre değişen sırada normalize edilmiş bileşen hedeflerini tutuyor.

CSV'nin **3.000 satırının tamamı**, CSV yuvarlama toleranslarıyla eğitim NPZ'sine eşleşiyor; doğrulama eşleşmesi yok. CSV ayrı bir test kümesi değildir. Eşleşen fiziksel bileşenlerle doğrulanan, fakat paket tarafından belgelenmeyen dönüşüm:

- Direnç: `R = 10^(2 + 4u)` Ω; alan 100 Ω–1 MΩ.
- Kondansatör: `C = 10^(-10 + 5u)` F; alan 100 pF–10 µF.
- İndüktör: `L = 10^(-6 + 5u)` H; alan 1 µH–100 mH.

Topoloji eşlemesi: `0 sk_lp2`, `1 sk_hp2`, `2 mfb_lp2`, `3 mfb_bp2`, `4 rc_lp2`, `5 rlc_lp2`, `6 sk_lp4`, `7 sk_lp2g`, `8 sk_hp2g`, `9 sk_lp4g`. Türler: `0 lowpass`, `1 highpass`, `2 bandpass`. Her topolojinin tam U kolon sırası ve dönüşümün sayısal uyum hatası `data-audit.json` içinde. Maksimum eşleştirme artığı yaklaşık 1,7×10⁻⁷ log10 birimi; tüm çözümlenen bileşenler 1 ppm içinde E24 değerlerine uyuyor.

**Maskeleme:** Kullanılmayan U kolonları sıfır, fakat aktif bir bileşenin en küçük değeri de sıfır olarak kodlanıyor: toplam 4.006 aktif sıfır var. Maske `U != 0` ile değil, topolojiye ait kolon şemasıyla oluşturulmalı. Her iki NPZ topolojiye göre bloklar halinde sıralı; eğitim sırasında karıştırılmalı.

## Sayısal sağlık ve veri ayrımı

- `p05_drop` dışındaki dizilerde NaN/sonsuz değer yok; U tamamıyla [0,1] aralığında.
- Eğitimde 30.219, doğrulamada 3.978 Monte Carlo etiketi var. Kalan yaklaşık %75 NaN; `has_mc` bu eksiklerle bire bir tutarlı. Eksikler sıfır etiket olarak doldurulmamalı; ilgili kayıp maskelenmeli.
- Tam satır veya tam giriş özelliği tekrarları iki küme arasında yok.
- **113 farklı topoloji+bileşen vektörü iki kümede ortak. Doğrulamanın 114 satırı (%0,715) eğitimde görülmüş devreler:** 112 RLC, 2 yüksek geçiren Sallen-Key. Eğitim içinde 435, doğrulama içinde 14 fazladan devre tekrarı var. Aynı fiziksel devre grupları tek ayrımda tutulmalı; bu örtüşme mevcut `sk_lp2` alt kümesinde bulunmadı.
- Her iki kümede yalnızca 176 farklı `fc` ve 11 farklı `stop_ratio` var. Rastgele satır ayrımı yeni frekans bölgelerine genelleme kanıtı sağlamaz.

## Mevcut simülatörle karşılaştırma

Okunan `lib/circuit.ts` modeli:

`H(s) = 1 / [1 + s·C2·(R1+R2) + s²·R1·R2·C1·C2]`.

Mevcut uygulama birim kazançlı, ikinci derece alçak geçiren Sallen-Key kullanıyor. Paketin yalnızca `topo_id=0` olan **18.075** satırı bu ailede. Bunlardan **1.821** tanesi uygulamanın mevcut R=1–100 kΩ, C=1–100 nF sınırlarında. Diğer dokuz topoloji aynı formüle yönlendirilemez. Uygulamada kazanç hedefi 0 dB ve durdurma bastırması mutlak; pakette değişken kazanç hedefi ve kesinleştirilmemiş bastırma tanımı bulunuyor.

**Doğrudan CSV ideal-model uyumsuzluk örneği — fiziksel değerlerden, U çözümlemesine bağlı değil:** CSV veri satırı 1043 (0 tabanlı; dosya satırı 1045), `sk_lp2`: R1=6.200 Ω, R2=110 Ω, C1=110 nF, C2=110 pF; fc=19.952,62 Hz; oran=5,595; hedef kazanç=1,52 dB; istenen bastırma=16,84 dB; bildirilen garanti marjı **+1,962 dB**. Durdurma sınırı 111.634,9089 Hz olur. Mevcut formül bu noktada **9,8231 dB mutlak bastırma**, hedef kazanca göre **11,3431 dB bağıl bastırma** verir. İki yorumda da hedef sağlanmaz; bağıl marj **−5,4969 dB**. CSV yuvarlama hatası bu farkı açıklamaz.

`fc` geçirme üst sınırı, geçirme hedefi `gain ± ripple`, durdurma başlangıcı `fc × stop_ratio` kabul edilerek tüm 18.075 satırın analitik bant uçları/tepe noktaları denetlendi. Bağıl bastırma gibi daha uygun yorumda bile **448 satır (%2,479; eğitim 405, doğrulama 43)** 0,01 dB'den fazla ihlal ediyor. Bunların 447'si doğrudan durdurma başlangıcında da başarısız. Mutlak bastırma yorumunda 2.109 ihlal var. Bu sayılar ideal op-amp modeli ve belirtilen bant tanımlarına bağlıdır; özgün `FilterSpec` tanımı pakette bulunmadığı için üreticinin hangi işlemi yaptığı kesinleştirilemez.

Veri kartındaki “−3 dB kesim frekansı” açıklaması da mevcut formülle uyuşmuyor: 18.075 satırın hiçbirinin `fc` değeri hesaplanan −3 dB frekansına %1 yakın değil; medyan `fc/f₋₃dB`=0,643. Bu alanın geçirme sınırı olarak seçilmiş olması daha olasıdır; bu bir çıkarımdır. C1/C2 adlarını değiştirmek uyumu çok kötüleştiriyor, dolayısıyla basit bir kapasitör adı takası sorunu çözmüyor. **Kanıt mevcut uygulama ile etiketlerin uyumsuzluğudur; üretici netlisti olmadan onun devre denkleminin kesinlikle yanlış olduğu ileri sürülemez.**

## Eğitime alınmadan önce gerekenler

1. Üretici kaynak kodu/sürümü, 10 netlist, topoloji ve U manifestosu, kesin pass/stop aralıkları ve bastırma referansı kaydedilmeli. Bugünkü denetim bunları yeniden üretilebilir biçimde paket içinde bulamadı.
2. Önce `sk_lp2` için özgün sonlu op-amp modeli ve bant tanımları eşleştirilmeli; etiketler aynı fiziksel modelle yeniden hesaplanıp bağımsız SPICE değerlendirmesinden geçirilmeli. İdeal motor için ayrı veri sürümü oluşturulursa etiketler o modele göre yeniden üretilmeli. Ters etiketleme, kullanılan simülatör ve bant ölçümü yanlışsa doğru etiket garantisi vermez. Veri kartı zaten 400 örnekte %0,25 geçersiz sonuç bildiriyor; “etiket gürültüsüz” iddiası buna da aykırı.
3. Monte Carlo tolerans yüzdeleri, dağılımı, korelasyonları, çekiliş sayısı/tohumu ve `p05_drop` tanımı getirilmeli. Bunlar olmadan dayanıklılık hedefi tekrarlanamaz veya uygulamanın %1 R/%5 C varsayılanıyla eşitlenemez.
4. Fiziksel devreye göre gruplanmış yeni ayrım ve ayrı frekans/özellik sınaması kurulmalı. Tasarım üreticisinin girdileri yalnızca istenen spec olmalı; çözümden hesaplanan `margin`/`p05_drop` girişe eklenmemeli. Dayanıklılık tahmininde ise giriş topoloji+bileşen+spec+tolerans tanımı olmalı, kayıp yalnızca etiketli satırlarda hesaplanmalı.

Paket optimal tasarım, fiziksel ölçüm veya hazır bir eğitilmiş AI sağlamıyor; doğrulanırsa tasarım başlangıç tahmini ve ayrı dayanıklılık araştırması için değerlendirilebilir. Sayılar, dosya SHA-256 özetleri, örnekler ve çıkarılmış şema `data-audit.json` içinde.
