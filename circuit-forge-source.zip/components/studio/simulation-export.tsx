'use client';
import { useMemo, useState } from 'react';
import { Download, ExternalLink, Play, CheckCircle2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { createWokwiProject, wokwiSupport } from '@/lib/hardware/wokwi';
import type { HardwarePlan } from '@/lib/hardware/types';
import { zipTextFiles } from '@/lib/zip';
import { saveFile } from '@/lib/save-file';
export function SimulationExport({ plan }: { plan: HardwarePlan }) {
  const [interactive, setInteractive] = useState(true),
    [notice, setNotice] = useState('');
  const support = wokwiSupport(plan);
  const hasPot = plan.items.some((i) => i.component.id === 'pot-10k');
  const project = useMemo(
    () => (support.supported ? createWokwiProject(plan, interactive) : null),
    [plan, interactive, support.supported],
  );
  return (
    <div className="simulation-export">
      <div className="sim-heading">
        <span className="sim-symbol">
          <Play size={24} />
        </span>
        <div>
          <h3>Devreni Wokwi’de çalıştır.</h3>
          <p>Kod, bağlantılar ve gerekli kütüphaneler tek pakette.</p>
        </div>
      </div>
      {project ? (
        <>
          <div className="sim-ready">
            <CheckCircle2 size={17} />
            {plan.board.name} · {plan.items.length} modül eşleşti ·{' '}
            {project.diagram.connections.length} bağlantı
          </div>
          <div className="sim-toggle">
            <div>
              <strong>Potansiyometre → LED ve ekran</strong>
              <p>
                {hasPot
                  ? 'Plana LED veya OLED eklediğinde pot onları kontrol eder.'
                  : 'Bu etkileşim için plana potansiyometre ekle.'}
              </p>
            </div>
            <Switch
              aria-label="Potansiyometre etkileşimli örneği"
              disabled={!hasPot}
              checked={hasPot && interactive}
              onCheckedChange={setInteractive}
            />
          </div>
          <div className="sim-actions">
            <Button
              onClick={() => {
                saveFile(
                  'CircuitForge-' + plan.board.id + '.zip',
                  zipTextFiles(project.files),
                  'application/zip',
                );
                setNotice(
                  'Proje paketi indirildi. Wokwi’de aynı kart için yeni proje açıp dosyaları ekle.',
                );
              }}
            >
              <Download size={16} />
              Wokwi projesini indir
            </Button>
            <a
              className="studio-secondary"
              href="https://wokwi.com/"
              target="_blank"
              rel="noreferrer"
            >
              Wokwi’yi aç <ExternalLink size={15} />
            </a>
          </div>
          <ol className="sim-steps">
            <li>Aynı kart için Arduino/C++ projesi aç.</li>
            <li>
              Paketteki <code>sketch.ino</code>, <code>diagram.json</code> ve{' '}
              <code>libraries.txt</code> içeriklerini ilgili dosyalara ekle.
            </li>
            <li>Play’e bas; potu çevir, butona bas ve seri monitörü izle.</li>
          </ol>
          <div className="sim-file-row">
            {['diagram.json', 'sketch.ino', 'libraries.txt'].map((name) => (
              <button
                key={name}
                onClick={() => saveFile(name, project.files[name])}
              >
                <Download size={13} />
                {name}
              </button>
            ))}
          </div>
          <details>
            <summary>Simülasyon kapsamı ve model farkları</summary>
            {project.notes.map((n) => (
              <p key={n}>{n}</p>
            ))}
            <p>
              Dosyalar otomatik yüklenmez. Bu sitedeki bağlantı masası bir MCU
              emülatörü değildir; kodu Wokwi çalıştırır.
            </p>
            <a
              href="https://docs.wokwi.com/diagram-format"
              target="_blank"
              rel="noreferrer"
            >
              Wokwi belgeleri
            </a>
          </details>
        </>
      ) : (
        <div className="sim-unavailable">
          <Info size={22} />
          <div>
            <h4>Bu planın tamamı henüz aktarılamıyor.</h4>
            <ul>
              {support.reasons.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
            <p>
              Başlangıç: destekli kart + LED + potansiyometre + buton. OLED ve
              DHT22 de ekleyebilirsin.
            </p>
          </div>
        </div>
      )}
      <output aria-live="polite">{notice}</output>
    </div>
  );
}
