import type {
  Board,
  Component,
  Selection,
  HardwarePlan,
  PlannedItem,
  Issue,
  Wire,
} from './types.ts';

export function planHardware(
  board: Board,
  components: Component[],
  selections: Selection[],
): HardwarePlan {
  const issues: Issue[] = [],
    wires: Wire[] = [],
    items: PlannedItem[] = [],
    used = new Set<string>(),
    addresses = new Map<number, string>();
  const profile = board.profile;
  const warn = (
    severity: Issue['severity'],
    code: string,
    text: string,
    itemId?: string,
  ) => issues.push({ severity, code, text, itemId });
  if (!profile)
    warn(
      'error',
      'BOARD_PROFILE',
      'Bu kart katalogda kayıtlı. Otomatik pin atama ve kod üretimi için doğrulanmış bir profil henüz eklenmedi.',
    );
  if (selections.length > 8)
    warn(
      'error',
      'ITEM_LIMIT',
      'Bir planda en fazla 8 modül desteklenir. Daha büyük sistemi alt devrelere ayır.',
    );
  if (new Set(selections.map((s) => s.id)).size !== selections.length)
    warn('error', 'DUPLICATE_ID', 'Modül kimlikleri benzersiz olmalı.');
  const i2cNeeded = selections.some((s) =>
    components
      .find((c) => c.id === s.componentId)
      ?.interface.toUpperCase()
      .includes('I2C'),
  );
  if (i2cNeeded && profile) {
    used.add(profile.i2c.sda);
    used.add(profile.i2c.scl);
  }
  function take(
    pool: string[],
    itemId: string,
    signal: string,
    role: Wire['role'],
  ): string | undefined {
    const pin = pool.find((p) => !used.has(p));
    if (!pin) {
      warn(
        'error',
        'PIN_CAPACITY',
        `${signal} için boş ${role === 'analog' ? 'analog' : role === 'pwm' ? 'PWM' : 'dijital'} pin kalmadı.`,
        itemId,
      );
      return;
    }
    used.add(pin);
    wires.push({ itemId, signal, boardPin: pin, role });
    return pin;
  }
  for (const selection of selections) {
    const c = components.find((c) => c.id === selection.componentId);
    if (!c) {
      warn(
        'error',
        'UNKNOWN_PART',
        'Parça katalogda bulunamadı.',
        selection.id,
      );
      continue;
    }
    const item: PlannedItem = {
      selection,
      component: c,
      pins: {},
      power: null,
    };
    items.push(item);
    if (!c.template)
      warn(
        'error',
        'CATALOG_ONLY',
        `${c.name}: kaynak ve uyumluluk bilgisi var; çalıştırılabilir kod şablonu henüz yok.`,
        selection.id,
      );
    if (
      board.logicVoltage &&
      c.logicMax !== null &&
      board.logicVoltage > c.logicMax + 0.05 &&
      c.interface !== 'Analog'
    )
      warn(
        'error',
        'LOGIC_LEVEL',
        `${c.name}: ${board.logicVoltage} V lojik, ${c.logicMax} V giriş sınırını aşıyor. Seviye dönüştürücü bağlantısı ayrıca tasarlanmalı.`,
        selection.id,
      );
    if (c.supplyRange) {
      const [lo, hi] = c.supplyRange;
      let voltage: number | null = null;
      if (
        board.logicVoltage &&
        board.logicVoltage >= lo &&
        board.logicVoltage <= hi
      )
        voltage = board.logicVoltage;
      else if (lo <= 3.3 && hi >= 3.3) voltage = 3.3;
      else if (lo <= 5 && hi >= 5 && board.logicVoltage === 5) voltage = 5;
      if (voltage !== null) item.power = `${voltage}V`;
      else
        warn(
          'warning',
          'EXTERNAL_RAIL',
          `${c.name}: ${lo}–${hi} V ayrı besleme gerekir; kartın güç pinleri kontrol edilmeli.`,
          selection.id,
        );
    }
    if (c.externalPower)
      warn(
        'warning',
        'MOTOR_POWER',
        `${c.name}: yükü GPIO veya kartın küçük regülatöründen besleme. Uygun harici besleme ve ortak GND kullan.`,
        selection.id,
      );
    if (c.template === 'hcsr04' && board.logicVoltage !== 5)
      warn(
        'error',
        'ECHO_LEVEL',
        'HC-SR04 ECHO çıkışı 5 V olabilir. 3,3 V kart için gerilim bölücü/seviye dönüştürücü gerekir; bu doğrudan bağlantı şablonu yalnız 5 V kartlarda açılır.',
        selection.id,
      );
    if (c.template === 'lm35' && board.logicVoltage !== 5)
      warn(
        'error',
        'LM35_SUPPLY',
        'LM35 en az 4 V besleme ister. Bu basit şablon 5 V kartlar içindir; 3,3 V sistem için harici besleme ve giriş aralığı ayrı doğrulanmalı.',
        selection.id,
      );
    if (c.interface.toUpperCase().includes('I2C')) {
      const address = selection.address ?? c.addresses[0];
      if (address === undefined)
        warn(
          'warning',
          'ADDRESS_UNKNOWN',
          `${c.name}: adresi üreticinin belgesinden doğrula.`,
          selection.id,
        );
      else if (!c.addresses.includes(address))
        warn(
          'error',
          'INVALID_ADDRESS',
          `${c.name}: seçilen adres bu katalog kaydında doğrulanmamış.`,
          selection.id,
        );
      else if (addresses.has(address))
        warn(
          'error',
          'I2C_CONFLICT',
          `I²C 0x${address.toString(16).toUpperCase()} adresinde çakışma: ${addresses.get(address)} ve ${c.name}. Adres jumperını veya modülü değiştir.`,
          selection.id,
        );
      else addresses.set(address, c.name);
      if (profile && c.template) {
        item.pins.SDA = profile.i2c.sda;
        item.pins.SCL = profile.i2c.scl;
        wires.push(
          {
            itemId: selection.id,
            signal: 'SDA',
            boardPin: profile.i2c.sda,
            role: 'i2c',
          },
          {
            itemId: selection.id,
            signal: 'SCL',
            boardPin: profile.i2c.scl,
            role: 'i2c',
          },
        );
      }
    }
    for (const extra of c.additionalAddresses ?? []) {
      if (addresses.has(extra))
        warn(
          'error',
          'I2C_CONFLICT',
          `I²C 0x${extra.toString(16)} ek adresinde çakışma: ${c.name} ve ${addresses.get(extra)}.`,
          selection.id,
        );
      else addresses.set(extra, c.name);
    }
    if (!profile || !c.template || c.template === 'passive') continue;
    const bind = (signal: string, role: 'digital' | 'analog' | 'pwm') => {
      const pin = take(
        role === 'analog'
          ? profile.analog
          : role === 'pwm'
            ? profile.pwm
            : profile.digital,
        selection.id,
        signal,
        role,
      );
      if (pin) item.pins[signal] = pin;
    };
    switch (c.template) {
      case 'led':
        bind('ANODE', 'digital');
        break;
      case 'rgb':
        bind('R', 'pwm');
        bind('G', 'pwm');
        bind('B', 'pwm');
        break;
      case 'button':
        bind('SIGNAL', 'digital');
        break;
      case 'analog':
      case 'tmp36':
      case 'lm35':
      case 'filter':
        bind('OUT', 'analog');
        break;
      case 'piezo':
        bind('SIGNAL', 'digital');
        break;
      case 'servo':
        bind('SIGNAL', 'digital');
        break;
      case 'ssd1306':
        bind('RESET', 'digital');
        break;
      case 'hcsr04':
        bind('TRIG', 'digital');
        bind('ECHO', 'digital');
        break;
      case 'dht22':
      case 'ds18b20':
        bind('DATA', 'digital');
        break;
    }
    if (c.template === 'filter')
      warn(
        'warning',
        'ANALOG_INPUT',
        'Filtre çıkışı GND ile ADC giriş sınırı arasında kalmalı. Bipolar/negatif sinyal doğrudan bağlanmaz; gerekiyorsa bias ve koruma eklenir. İdeal op-amp modeli gerçek besleme sınırlarını doğrulamaz.',
        selection.id,
      );
    if (c.template === 'analog')
      warn(
        'info',
        'DIVIDER_WIRING',
        `${c.name}: OUT analog girişidir. Potansiyometre orta ucu veya sensör + 10 kΩ bölücünün orta noktası kullanılır; fiziksel birim için kalibrasyon gerekir.`,
        selection.id,
      );
    if (c.template === 'analog' && board.profile?.adc === 'esp32')
      warn(
        'warning',
        'ADC_RANGE',
        'ESP32 ADC ölçüm aralığı çipe ve zayıflatma ayarına bağlıdır. Potansiyometre üst uçta doyabilir; ham değer ve kalibre mV ayrı raporlanır.',
        selection.id,
      );
    if (c.template === 'led' || c.template === 'rgb')
      warn(
        'info',
        'LED_RESISTOR',
        `${c.name}: her LED kanalına seri 1 kΩ direnç ekle; toplam GPIO akım sınırları kart belgesinden kontrol edilmeli.`,
        selection.id,
      );
    if (c.template === 'ds18b20' || c.template === 'dht22')
      warn(
        'info',
        'DATA_PULLUP',
        `${c.name}: DATA ile lojik besleme arasına 4,7 kΩ pull-up ekle. Parazit besleme kullanılmaz.`,
        selection.id,
      );
    if (
      c.template === 'piezo' &&
      items.filter((v) => v.component.template === 'piezo').length > 1
    )
      warn(
        'error',
        'TONE_RESOURCE',
        'Bu şablon aynı anda tek pasif piezo destekler; tone() zamanlayıcısı paylaşılır.',
        selection.id,
      );
    if (c.template === 'servo' && profile.adc === 'esp32')
      warn(
        'error',
        'SERVO_CORE',
        'Bu Servo kütüphane şablonu ESP32 üzerinde doğrulanmadı. ESP32 uyumlu servo sürücüsü gerekir.',
        selection.id,
      );
    // Ground and supply are explicitly schematic, not physical header pin positions.
    wires.push({
      itemId: selection.id,
      signal:
        c.template === 'led'
          ? 'CATHODE'
          : c.template === 'rgb'
            ? 'COMMON CATHODE'
            : 'GND',
      boardPin: 'GND',
      role: 'ground',
    });
    if (!['led', 'rgb', 'button', 'piezo', 'filter'].includes(c.template)) {
      const rail = c.externalPower ? 'HARİCİ V+' : item.power;
      if (rail)
        wires.push({
          itemId: selection.id,
          signal: 'VCC / VIN',
          boardPin: rail,
          role: 'power',
          note: c.externalPower ? 'Kart GND ile ortak referans.' : undefined,
        });
    }
  }
  if (items.filter((i) => i.component.template === 'hcsr04').length > 1)
    warn(
      'error',
      'ULTRASONIC_CROSSTALK',
      'Birden fazla HC-SR04 yankıları birbirini etkiler. Bu zamanlama şablonu yalnız bir ultrasonik sensör destekler.',
    );
  if (
    items.filter((i) => i.component.template === 'ssd1306').length > 1 &&
    board.mcu.includes('328')
  )
    warn(
      'error',
      'OLED_RAM',
      'İki OLED tamponu ATmega328P SRAM kapasitesini doldurur. Daha büyük kart veya tek ekran seç.',
    );
  if (
    items.some((i) => i.component.template === 'ssd1306') &&
    board.profile?.adc === 'avr10'
  )
    warn(
      'warning',
      'OLED_MEMORY',
      '128×64 OLED 1.024 bayt dinamik RAM tamponu ayırır. Derleme raporu bu heap kullanımını içermez; sensörlerle birlikte çalışma belleği ayrıca doğrulanmalı.',
    );
  if (
    items.some((i) => i.component.template === 'servo') &&
    items.some((i) => i.component.template === 'rgb')
  )
    warn(
      'error',
      'TIMER_CONFLICT',
      'Servo ve RGB PWM zamanlayıcıları bazı kartlarda çakışır. Bu şablonda ayrı planlar kullan.',
    );
  if (
    items.some((i) => i.component.template === 'piezo') &&
    items.some((i) => i.component.template === 'rgb')
  )
    warn(
      'error',
      'TIMER_CONFLICT',
      'tone() ve RGB PWM zamanlayıcıları kart çekirdeğine göre çakışabilir. Bu şablonda ayrı planlar kullan.',
    );
  if (
    items.some((i) => i.component.template === 'ssd1306') &&
    items.filter((i) => i.component.library).length > 2 &&
    board.mcu.includes('328')
  )
    warn(
      'warning',
      'RAM_BUDGET',
      'SSD1306 görüntü tamponu 1.024 bayt kullanır. ATmega328P üzerinde ek sensörlerle RAM sınıra yaklaşabilir; IDE derleme raporunu kontrol et.',
    );
  if (i2cNeeded)
    warn(
      'info',
      'I2C_PULLUPS',
      'Plan kartın varsayılan Wire/header I²C hattını kullanır. Qwiic/ikinci Wire hattı farklı olabilir. Pull-up gerilimi ve toplam pull-up direnci kontrol edilmeli.',
    );
  return {
    board,
    items,
    wires,
    issues,
    libraries: [
      ...new Set(
        items.map((i) => i.component.library).filter((v): v is string => !!v),
      ),
    ],
    canGenerate:
      !!profile &&
      items.some(
        (i) => i.component.template && i.component.template !== 'passive',
      ) &&
      !issues.some((i) => i.severity === 'error'),
    usedPins: [...used],
    unsupported: items.filter((i) => !i.component.template).length,
  };
}
