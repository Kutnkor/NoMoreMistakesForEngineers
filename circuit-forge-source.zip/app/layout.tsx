import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'CIRCUIT FORGE — Embedded Studio & AI Laboratuvarı',
  description:
    'Arduino, ESP32 ve Pico için bağlantı ve Wokwi projeleri oluştur. Sonlu op-amp modeli, eğitilmiş arıza AI ve eşit bütçeli tasarım deneylerini incele.',
  icons: { icon: '/favicon.svg' },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
