/* oxlint-disable next/no-html-link-for-pages -- This static export uses native page navigation, including disposal of page-scoped workers. */
import {
  ArrowLeft,
  ArrowUpRight,
  CheckCircle2,
  CircuitBoard,
  Download,
  FlaskConical,
} from 'lucide-react';
import compiles from '@/research/arduino-compile-results.json';
import benchmark from '@/research/benchmark.json';
import fault from '@/research/fault-model-report.json';
import spice from '@/research/ngspice-validation.json';
import budget from '@/research/budget-benchmark.json';
import embedded from '@/research/embedded-validation.json';
import '../studio.css';
export default function EvidencePage() {
  const mean = (key: 'aiYield' | 'randomYield') =>
    benchmark.seeds.reduce((s, x) => s + x[key], 0) / benchmark.seeds.length;
  return (
    <div className="studio-shell">
      <header className="studio-topbar">
        <a className="studio-brand" href="/">
          <span className="brand-mark">
            <CircuitBoard size={23} />
          </span>
          <div>
            CIRCUIT<span>FORGE</span>
            <small>RESEARCH & VALIDATION</small>
          </div>
        </a>
        <a href="/" className="source-link">
          <ArrowLeft size={14} /> Kart Studio
        </a>
      </header>
      <main className="studio-main evidence-main">
        <div className="studio-heading">
          <div>
            <div className="eyebrow">KANIT / 05 EYLÜL 2026</div>
            <h1>Ölçülebilir mühendislik.</h1>
            <p>
              Hangi testlerin geçtiği, nerede sınırlar olduğu ve sonuçların
              nasıl tekrar üretileceği.
            </p>
          </div>
        </div>
        <div className="evidence-grid">
          <section className="studio-panel evidence-card">
            <div className="eyebrow">BREADBOARD / BAĞLANTI DOĞRULAMASI</div>
            <h2>
              5<span>/5</span>
            </h2>
            <h3>Örnek devre şemayla eşleşti.</h3>
            <p>
              830 delik, 134 bağımsız bakır grup. Yanlış bacak, kısa devre,
              kopuk ray ve delik çakışması denetlenir. Toplam 49 otomatik test;
              16 breadboard testi.
            </p>
            <p>
              Gerçek tarayıcıda 2D/3D sürükleme, jumper takibi, karşılıklı vurgu
              ve öğrenme adımları sınandı. Beş PDF kılavuzu tek sayfa olarak
              doğrulandı.
            </p>
            <div className="evidence-note">
              Apple M4 / Metal ölçümünde 3D sürükleme 119 FPS. Cihaz ve
              tarayıcıya bağlıdır. Şema eşleşmesi, analog performans veya
              fiziksel donanım doğrulaması değildir.
            </div>
            <a href="/breadboard">
              Breadboard Lab’ı aç <ArrowUpRight size={14} />
            </a>
            <a href="/reports/breadboard-browser-validation.json" download>
              Tarayıcı test raporu <Download size={14} />
            </a>
            <a href="/reports/breadboard-methods.md" download>
              Yöntemler ve sınırlar <Download size={14} />
            </a>
          </section>

          <section className="studio-panel evidence-card">
            <div className="eyebrow">WOKWI / ESP32 / RASPBERRY PI PICO</div>
            <h2>
              {embedded.compiles.passed}
              <span>/{embedded.compiles.total}</span>
            </h2>
            <h3>Yeni dışa aktarım örneği derlendi.</h3>
            <p>
              Wokwi CLI ile {embedded.diagrams.passed}/{embedded.diagrams.total}{' '}
              bağlantı dosyası denetlendi. UNO, Nano, Mega, ESP32-DevKitC V4 ve
              Pico üzerinde LED + pot + buton + OLED örneği; UNO, ESP32 ve Pico
              için tekil modül derlemeleri.
            </p>
            <p>
              Wokwi CLI 0.26.1 · Arduino CLI 1.5.1 · ESP32 3.3.11 · Arduino-Pico
              6.1.0.
            </p>
            <div className="evidence-note">
              Bu kontroller bağlantı dosyası ve C++ derlemesi içindir. Wokwi
              bulutunda yürütme ve fiziksel donanım testi yapılmadı. ESP32/Pico
              üzerinde 5 V HC-SR04 eşlemesi engellenir.
            </div>
            <a href="/reports/embedded-validation.json" download>
              <Download size={14} />
              Yeni derleme ve bağlantı raporu
            </a>
          </section>
          <section className="studio-panel evidence-card">
            <div className="eyebrow">ARDUINO / DERLEME</div>
            <h2>
              {compiles.passed}
              <span>/{compiles.total}</span>
            </h2>
            <h3>Örnek sketch derlendi.</h3>
            <p>
              9 kartta LED + potansiyometre + buton. UNO R3 üzerinde 24 modül
              şablonu ayrı ayrı; BME280 + OLED birlikte.
            </p>
            <p>
              Arduino CLI 1.5.1 · AVR 1.8.8 · megaAVR 1.8.8 · Renesas UNO 1.6.0
              · SAMD 1.8.14.
            </p>
            <div className="evidence-note">
              Nano ESP32 kod profili bu derleme matrisinde yok. Başarılı
              derleme, tüm kombinasyonların elektriksel veya fiziksel
              doğrulaması değildir.
            </div>
            <a href="/reports/arduino-compile-results.json" download>
              <Download size={14} /> Derleme raporu JSON
            </a>
          </section>
          <section className="studio-panel evidence-card">
            <div className="eyebrow">FİLTRE AI / 10 DENEY</div>
            <h2>
              {mean('aiYield').toFixed(1)}
              <span>%</span>
            </h2>
            <h3>Ortalama bağımsız tolerans verimi.</h3>
            <p>
              Aynı bütçeli rastgele arama: %{mean('randomYield').toFixed(1)}.
              Her yönteme 64 devre değerlendirmesi; sonuç başına 1.024 yeni
              tolerans çekilişi.
            </p>
            <p>
              Önceden seçilmiş 0–9 tohumları, tek Sallen–Key topolojisi ve ideal
              op-amp modeliyle varsayılan hedefler. AI eğitim skorunda 7,
              rastgele arama 3 deneyde daha iyi.
            </p>
            <div className="evidence-note">
              Bu küçük deney, genel üstünlük veya fiziksel devre performansı
              kanıtlamaz. Test sonuçları aday seçimine katılmadı.
            </div>
            <a href="/reports/filter-benchmark.json" download>
              <Download size={14} /> Deney sonuçları JSON
            </a>
          </section>
        </div>
        <div className="evidence-grid">
          <section className="studio-panel evidence-card">
            <div className="eyebrow">SONLU OP-AMP / BAĞIMSIZ NGSPICE</div>
            <h2>{spice.points.toLocaleString('tr-TR')}</h2>
            <h3>Frekans noktasında karşılaştırma.</h3>
            <p>
              30 devre, 1 Hz–100 MHz taraması. Tarayıcının analitik sonucu,
              ngspice 47’nin bağımsız AC çözümüyle karşılaştırıldı. En büyük
              bağıl fark {spice.maxRelativeError.toExponential(2)}.
            </p>
            <div className="evidence-note">
              Tek kutuplu sonlu op-amp ve tek Sallen–Key topolojisi. Sayısal
              uyuşma; doyum, slew rate, parazit veya fiziksel ölçüm doğrulaması
              değildir.
            </div>
            <a href="/reports/ngspice-validation.json" download>
              <Download size={14} />
              Karşılaştırma raporu
            </a>
          </section>
          <section className="studio-panel evidence-card">
            <div className="eyebrow">ARIZA AI / AYRI TUTULAN TEST</div>
            <h2>%{fault.test.top1AccuracyPct}</h2>
            <h3>En yüksek skorlu sınıf doğru.</h3>
            <p>
              24 girişli, 32 gizli birimli sinir ağı. 800 eğitim, 200 doğrulama
              ve 200 ayrı test devresi; testte 1.200 sentetik ölçüm.
            </p>
            <p>
              Sağlıklı 200 ölçümde 0 yanlış alarm; arızalı 1.000 ölçümde 2
              kaçırılan arıza. 14 sonuç belirsiz bırakıldı. Belirsizleri yanlış
              sayan toplam doğruluk %97,5.
            </p>
            <div className="evidence-note">
              Altı tekil durum, bilinen nominal devre ve giriş yanıtı. Gerçek
              donanım veya aynı anda birden fazla arıza için başarı iddiası
              yoktur. 0/200 sonucu, gelecekte sıfır yanlış alarm garantisi
              vermez.
            </div>
            <a href="/reports/fault-model-report.json" download>
              <Download size={14} />
              Model kartı ve sınıf matrisi
            </a>
          </section>
        </div>
        <section className="studio-panel evidence-data">
          <div>
            <FlaskConical size={22} />
            <h2>Bütçe yöneten AI · 30 karşılaştırmalı deney</h2>
          </div>
          <p>
            Her yöntem 1.536 devre değerlendirmesi kullanır. Kazananlar
            sabitlendikten sonra 1.024 yeni tolerans çekilişi uygulanır.
            Aşağıdaki değer, 10 tohumdaki ortalama bağımsız tolerans verimidir.
          </p>
          <div className="table-scroll">
            <table className="wiring-table">
              <thead>
                <tr>
                  <th>GEÇİRME / DURDURMA</th>
                  <th>BÜTÇE YÖNETEN AI</th>
                  <th>STANDART GP</th>
                  <th>RASTGELE</th>
                </tr>
              </thead>
              <tbody>
                {budget.summary.map((row, i) => (
                  <tr key={row.condition}>
                    <td>
                      {budget.conditions[i].passHz.toLocaleString('tr-TR')} /{' '}
                      {budget.conditions[i].stopHz.toLocaleString('tr-TR')} Hz
                    </td>
                    {row.methods.map((m) => (
                      <td key={m.method}>
                        %
                        {m.meanYieldPct.toLocaleString('tr-TR', {
                          maximumFractionDigits: 1,
                        })}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p>
            Yeni yöntem bu deneyde 100 Hz koşulunda daha yüksek ortalama verim
            buldu; 1 kHz ve 10 kHz koşullarında standart GP önde. Her koşulda
            kazanma veya genel üstünlük iddiası yoktur. Hesaplama bütçesi eşit;
            duvar saati süreleri ayrıca raporlanır.
          </p>
          <a href="/reports/budget-benchmark.json" download>
            <Download size={14} />
            Tüm koşullar, adaylar ve sonuçlar
          </a>
          <a className="source-link" href="/lab">
            Deneyi kendin çalıştır <ArrowUpRight size={14} />
          </a>
        </section>
        <section className="studio-panel evidence-data">
          <div>
            <FlaskConical size={22} />
            <h2>Haricî veri seti incelemesi</h2>
          </div>
          <p>
            121.006 eğitim + 15.948 doğrulama örneği; 10 topoloji. Paket ham
            hâliyle eğitime bağlanmadı.
          </p>
          <div className="evidence-findings">
            <article>
              <strong>114</strong>
              <p>
                doğrulama satırının devre tasarımı eğitim kümesinde de var.
                Devre bazında ayırmak gerekli.
              </p>
            </article>
            <article>
              <strong>~%75</strong>
              <p>
                örnekte tolerans etiketi yok. Eksik değerler sıfır kayıp olarak
                ele alınamaz.
              </p>
            </article>
            <article>
              <strong>1.821</strong>
              <p>
                örnek mevcut topoloji ve R/C sınırlarına uyuyor. Bu sayı doğru
                etiket veya başarılı tasarım sayısı değil.
              </p>
            </article>
          </div>
          <p>
            Son çalışma dökümü model farkını ortaya çıkardı: veri üreticisi
            sonlu op-amp bant genişliği kullanıyor. Filtre AI sayfasının motoru
            ideal; yeni AI Laboratuvarı ayrıca bağımsız bir sonlu model sunuyor.
            Önceki iki uyuşmazlık örneği, açıklanan sonlu modelle yapılan
            bağımsız hesapta durdurma sınırını sağlıyor. Önceki ideal-model
            karşılaştırması yanlış etiket kanıtı olarak yorumlanmamalı.
          </p>
          <a href="/reports/data-audit.md" download>
            Veri inceleme raporunu indir <ArrowUpRight size={14} />
          </a>
        </section>
        <section className="studio-panel evidence-data">
          <div>
            <FlaskConical size={22} />
            <h2>Geliştirme günlüğü · Claude çalışması</h2>
          </div>
          <p>
            Son konuşma ve paylaşılan çalışma dökümü incelendi. 13 topolojiye
            genişletme, sıcaklık ve maliyet modelleri, KiCad netlist/BOM dışa
            aktarımı ile 41 testin geçtiği kayıtlar bulunuyor. Bunlar bu
            sitedeki doğrulama sonuçlarından ayrı tutuluyor.
          </p>
          <div className="evidence-findings">
            <article>
              <strong>100 dB / 10 MHz</strong>
              <p>
                Kaynak dökümünde belirtilen op-amp açık çevrim kazancı ve GBW.
              </p>
            </article>
            <article>
              <strong>Kaynak kodu</strong>
              <p>
                Güncel motor arşivi henüz alınmadı; 13 topoloji bu sitede etkin
                değil.
              </p>
            </article>
            <article>
              <strong>320 / 520</strong>
              <p>
                Yeni veri üretiminin görülen son ilerlemesi. Tamamlanmış yeni
                veri veya eğitim sonucu bulunmuyor.
              </p>
            </article>
          </div>
          <p>
            Entegrasyon sırası: aynı devrede iki motoru karşılaştırmak, topoloji
            ve veri sürümlerini eşleştirmek, ardından bağımsız testlerle yeni
            modeli bağlamak. Genelleme deneyindeki yanlış adlandırılmış fallback
            ve simülatör hata eşiği de inceleme raporunda kayıtlı.
          </p>
          <a href="/reports/claude-review.md" download>
            Çalışma incelemesini indir <ArrowUpRight size={14} />
          </a>
        </section>
        <section className="studio-panel evidence-table">
          <div className="panel-heading">
            <CheckCircle2 size={18} />
            <h2>Derleme matrisi</h2>
            <span className="mono-count">Donanım testi: yapılmadı</span>
          </div>
          <div className="table-scroll">
            <table className="wiring-table">
              <thead>
                <tr>
                  <th>KART / ÖRNEK</th>
                  <th>HEDEF (FQBN)</th>
                  <th>SONUÇ</th>
                </tr>
              </thead>
              <tbody>
                {compiles.cases.map((c) => (
                  <tr key={c.name}>
                    <td>{c.name.replaceAll('_', ' ')}</td>
                    <td>
                      <code>{c.fqbn}</code>
                    </td>
                    <td>
                      <span className="support-chip supported">Geçti</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <footer className="studio-footer">
          <span>AI yardımıyla geliştirilmiş araştırma prototipi</span>
          <a href="/filter">
            Filtre AI’ı aç <ArrowUpRight size={13} />
          </a>
          <a href="/reports/lab-methods.md" download>
            Laboratuvar yöntemleri <Download size={13} />
          </a>
          <a href="/">
            Arduino Studio <ArrowUpRight size={13} />
          </a>
        </footer>
      </main>
    </div>
  );
}
