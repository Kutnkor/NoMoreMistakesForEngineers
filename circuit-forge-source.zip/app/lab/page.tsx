'use client';
/* oxlint-disable next/no-html-link-for-pages -- Native navigation terminates page-scoped simulation workers. */
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  ArrowDownToLine,
  BrainCircuit,
  ChevronRight,
  CircuitBoard,
  FlaskConical,
  Play,
  RefreshCw,
  Square,
  AudioWaveform,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { LabPlot } from '@/components/lab/plot';
import {
  DEFAULT_SPECS,
  PART_KEYS,
  validateSpecs,
  type Parts,
  type Specs,
} from '@/lib/circuit';
import {
  checkModel,
  finiteMetrics,
  finiteNetlist,
  modelCurve,
  type OpAmp,
  finiteAudit,
} from '@/lib/lab/realistic';
import {
  FAULT_LABELS,
  FAULT_NAMES,
  makeFaultSample,
  predictFault,
  type Fault,
  type FaultModel,
} from '@/lib/lab/faults';
import { sensorSignal } from '@/lib/lab/signal';
import type { BudgetExperiment, BudgetMethod } from '@/lib/lab/adaptive';
import faultReport from '@/research/fault-model-report.json';
import { saveFile } from '@/lib/save-file';
import '../studio.css';
import './lab.css';

const methodNames: Record<BudgetMethod, string> = {
  adaptive: 'Bütçe yöneten AI',
  gp: 'Standart GP',
  random: 'Rastgele arama',
};
const methodColors: Record<BudgetMethod, string> = {
  adaptive: '#007f87',
  gp: '#7054b5',
  random: '#c27830',
};
const n = (x: number, d = 2) =>
  Number.isFinite(x)
    ? x.toLocaleString('tr-TR', { maximumFractionDigits: d })
    : '—';
const initial = {
  r1: '8.2',
  r2: '8.2',
  c1: '22',
  c2: '8.2',
  passHz: '1000',
  stopHz: '5000',
  rippleDb: '1',
  stopDb: '20',
  rTol: '1',
  cTol: '5',
  a0Db: '100',
  gbwMHz: '10',
  seed: '42',
};
type Fields = typeof initial;
type Audit = ReturnType<typeof finiteAudit>;
export default function LabPage() {
  const [tab, setTab] = useState('models'),
    [fields, setFields] = useState<Fields>(initial),
    [running, setRunning] = useState<'audit' | 'budget' | null>(null),
    [error, setError] = useState(''),
    [progress, setProgress] = useState({
      method: 'adaptive' as BudgetMethod,
      spent: 0,
      budget: 1536,
    }),
    [budget, setBudget] = useState('1536');
  const [audit, setAudit] = useState<{
      result: Audit;
      parts: Parts;
      specs: Specs;
      opAmp: OpAmp;
    } | null>(null),
    [experiment, setExperiment] = useState<BudgetExperiment | null>(null);
  const [fault, setFault] = useState<Fault>('c1-drift'),
    [faultSeed, setFaultSeed] = useState(101),
    [model, setModel] = useState<FaultModel | null>(null),
    [modelError, setModelError] = useState('');
  const [sampleHz, setSampleHz] = useState(200),
    [vibrationHz, setVibrationHz] = useState(450),
    [amplitude, setAmplitude] = useState(0.3);
  const worker = useRef<Worker | null>(null);
  useEffect(() => () => worker.current?.terminate(), []);
  useEffect(() => {
    const abort = new AbortController();
    fetch('/models/fault-mlp.json', { signal: abort.signal })
      .then(async (r) => {
        if (!r.ok) throw Error('Arıza modeli yüklenemedi.');
        const bytes = await r.arrayBuffer();
        const digest = await crypto.subtle.digest('SHA-256', bytes),
          hash = Array.from(new Uint8Array(digest))
            .map((x) => x.toString(16).padStart(2, '0'))
            .join('');
        if (hash !== faultReport.modelSha256)
          throw Error('Model sürümü raporla eşleşmiyor. Sayfayı yenile.');
        if (!abort.signal.aborted)
          setModel(JSON.parse(new TextDecoder().decode(bytes)) as FaultModel);
      })
      .catch((e) => {
        if (!abort.signal.aborted) setModelError(e.message);
      });
    return () => abort.abort();
  }, []);
  const parts = useMemo<Parts>(
    () => ({
      r1: Number(fields.r1) * 1000,
      r2: Number(fields.r2) * 1000,
      c1: Number(fields.c1) * 1e-9,
      c2: Number(fields.c2) * 1e-9,
    }),
    [fields.r1, fields.r2, fields.c1, fields.c2],
  );
  const opAmp = useMemo<OpAmp>(
    () => ({ a0Db: Number(fields.a0Db), gbwHz: Number(fields.gbwMHz) * 1e6 }),
    [fields.a0Db, fields.gbwMHz],
  );
  const specs = useMemo<Specs>(
    () => ({
      ...DEFAULT_SPECS,
      ...Object.fromEntries(
        ['passHz', 'stopHz', 'rippleDb', 'stopDb', 'rTol', 'cTol', 'seed'].map(
          (k) => [k, Number(fields[k as keyof Fields])],
        ),
      ),
    }),
    [fields],
  );
  let validation = validateSpecs(specs);
  try {
    checkModel(parts, opAmp);
  } catch (e) {
    validation = e instanceof Error ? e.message : String(e);
  }
  const valid = !validation;
  const curves = useMemo(
    () =>
      valid
        ? modelCurve(parts, opAmp, specs.passHz / 20, specs.stopHz * 20)
        : [],
    [valid, parts, opAmp, specs.passHz, specs.stopHz],
  );
  const nominal = valid ? finiteMetrics(parts, specs, opAmp) : null;
  const faultDomain =
    valid &&
    PART_KEYS.every(
      (k, i) =>
        parts[k] >= (i < 2 ? 1000 : 1e-9) * (1 - 1e-9) &&
        parts[k] <= (i < 2 ? 100000 : 1e-7) * (1 + 1e-9),
    ) &&
    opAmp.a0Db >= 80 &&
    opAmp.a0Db <= 120 &&
    opAmp.gbwHz >= 1e5 &&
    opAmp.gbwHz <= 1e8;
  const sample = useMemo(
    () =>
      faultDomain ? makeFaultSample(parts, fault, faultSeed, opAmp) : null,
    [faultDomain, parts, fault, faultSeed, opAmp],
  );
  const diagnosis =
    sample && model ? predictFault(model, sample.features) : null;
  const signal = useMemo(
    () =>
      valid
        ? sensorSignal(parts, opAmp, sampleHz, vibrationHz, amplitude)
        : null,
    [valid, parts, opAmp, sampleHz, vibrationHz, amplitude],
  );
  function update(k: keyof Fields, value: string) {
    setFields((f) => ({ ...f, [k]: value }));
  }
  function field(k: keyof Fields, label: string, unit: string) {
    return (
      <label className="lab-field" htmlFor={'lab-' + k}>
        <span>{label}</span>
        <div>
          <Input
            id={'lab-' + k}
            type="number"
            step="any"
            value={fields[k]}
            onChange={(e) => update(k, e.target.value)}
            disabled={!!running}
          />
          <small>{unit}</small>
        </div>
      </label>
    );
  }
  function run(type: 'audit' | 'budget') {
    if (validation) {
      setError(validation);
      return;
    }
    worker.current?.terminate();
    setError('');
    setRunning(type);
    setProgress({ method: 'adaptive', spent: 0, budget: Number(budget) });
    const w = new Worker(
      new URL('../../lib/lab/lab.worker.ts', import.meta.url),
      { type: 'module' },
    );
    worker.current = w;
    const snapshot = {
      parts: { ...parts },
      specs: { ...specs },
      opAmp: { ...opAmp },
    };
    w.onmessage = (e) => {
      const data = e.data;
      if (data.type === 'progress')
        setProgress({
          method: data.method,
          spent: data.spent,
          budget: data.budget,
        });
      else if (data.type === 'complete') {
        if (type === 'audit') setAudit({ ...snapshot, result: data.result });
        else setExperiment(data.result);
        setRunning(null);
        w.terminate();
        worker.current = null;
      } else if (data.type === 'error') {
        setError(data.message);
        setRunning(null);
        w.terminate();
        worker.current = null;
      }
    };
    w.onerror = () => {
      setError('Hesaplama tamamlanamadı. Yeniden deneyebilirsin.');
      setRunning(null);
      w.terminate();
      worker.current = null;
    };
    w.postMessage({ type, ...snapshot, budget: Number(budget) });
  }
  function cancel() {
    worker.current?.terminate();
    worker.current = null;
    setRunning(null);
    setError('Deney durduruldu. Önceki tamamlanmış sonuç korundu.');
  }
  const budgetCurves = experiment
    ? Array.from({ length: 96 }, (_, i) => {
        const cost = 384 + ((experiment.budget - 384) * i) / 95;
        const row: Record<string, number> = { x: cost };
        for (const m of experiment.methods) {
          let spent = 0,
            best = Infinity;
          for (const h of m.history) {
            if (spent + h.cost > cost) break;
            spent += h.cost;
            if (h.bestFullScore !== null) best = h.bestFullScore;
          }
          row[m.method] = Math.asinh(best);
        }
        return row as { x: number; [key: string]: number };
      })
    : [];
  return (
    <div className="studio-shell">
      <header className="studio-topbar">
        <a className="studio-brand" href="/">
          <span className="brand-mark">
            <CircuitBoard size={23} />
          </span>
          <div>
            CIRCUIT<span>FORGE</span>
            <small>RESEARCH LAB</small>
          </div>
        </a>
        <nav>
          <a href="/">Kart Studio</a>
          <span className="nav-active">AI Laboratuvarı</span>
          <a href="/filter">Filtre AI</a>
          <a href="/breadboard">Breadboard</a>
        </nav>
        <a className="source-link" href="/research">
          Deney kanıtları <ArrowUpRight size={15} />
        </a>
      </header>
      <main className="studio-main lab-main">
        <div className="studio-heading">
          <div>
            <div className="eyebrow">
              EEE / COMPUTER ENGINEERING / AEROSPACE
            </div>
            <h1>Tasarla. Sına. Öğren.</h1>
            <p>
              Aynı devrenin modelini, arızasını ve tasarım aramasını incele.
            </p>
          </div>
          <span className="lab-topology">
            <CircuitBoard size={17} /> Sallen–Key · LP2
          </span>
        </div>
        <div className="lab-layout">
          <aside className="studio-panel lab-controls">
            <div className="panel-heading">
              <FlaskConical size={19} />
              <h2>Deney ayarları</h2>
            </div>
            <div className="lab-control-body">
              <div className="lab-preset-buttons">
                <button disabled={!!running} onClick={() => setFields(initial)}>
                  1 kHz referans
                </button>
                <button
                  disabled={!!running}
                  onClick={() =>
                    setFields({
                      ...initial,
                      r1: '82',
                      r2: '82',
                      passHz: '100',
                      stopHz: '500',
                    })
                  }
                >
                  Sensör filtresi
                </button>
              </div>
              <div className="lab-section-label">REFERANS DEVRE</div>
              <div className="lab-field-grid">
                {field('r1', 'R1', 'kΩ')}
                {field('r2', 'R2', 'kΩ')}
                {field('c1', 'C1', 'nF')}
                {field('c2', 'C2', 'nF')}
              </div>
              <div className="lab-section-label">OP-AMP MODELİ</div>
              <div className="lab-field-grid">
                {field('a0Db', 'Açık çevrim kazancı', 'dB')}
                {field('gbwMHz', 'Bant genişliği × kazanç', 'MHz')}
              </div>
              <div className="lab-section-label">FİLTRE HEDEFİ</div>
              <div className="lab-field-grid">
                {field('passHz', 'Geçirme sınırı', 'Hz')}
                {field('stopHz', 'Durdurma sınırı', 'Hz')}
                {field('rippleDb', 'İzin verilen sapma', 'dB')}
                {field('stopDb', 'İstenen bastırma', 'dB')}
              </div>
              <div className="lab-section-label">TOLERANS VE TOHUM</div>
              <div className="lab-field-grid">
                {field('rTol', 'Direnç ±', '%')}
                {field('cTol', 'Kondansatör ±', '%')}
                {field('seed', 'Deney tohumu', '#')}
              </div>
              {validation && (
                <p className="lab-error" role="alert">
                  {validation}
                </p>
              )}
              <p className="lab-model-note">
                Birim kazançlı doğrusal AC modeli. Sonlu op-amp tek kutupludur.
                Doyum, slew rate, sıcaklık ve fiziksel ölçümler bu modelde
                yoktur.
              </p>
            </div>
          </aside>
          <div className="lab-workspace">
            <Tabs value={tab} onValueChange={(v) => setTab(String(v))}>
              <TabsList className="lab-tabs">
                <TabsTrigger value="models">Model karşılaştırma</TabsTrigger>
                <TabsTrigger value="faults">Arıza AI</TabsTrigger>
                <TabsTrigger value="budget">Akıllı arama</TabsTrigger>
                <TabsTrigger value="signal">Sensör sinyali</TabsTrigger>
              </TabsList>
              <TabsContent value="models">
                <section className="studio-panel lab-card">
                  <div className="lab-card-heading">
                    <div>
                      <div className="eyebrow">01 / FREKANS YANITI</div>
                      <h2>İdeal model neyi kaçırıyor?</h2>
                    </div>
                    <Button
                      variant="outline"
                      disabled={!valid}
                      onClick={() =>
                        saveFile(
                          'finite-sallen-key.cir',
                          finiteNetlist(parts, specs, opAmp),
                        )
                      }
                    >
                      <ArrowDownToLine size={15} />
                      SPICE
                    </Button>
                  </div>
                  <LabPlot
                    title="İdeal ve sonlu op-amp frekans yanıtı"
                    data={curves.map((p) => ({
                      x: p.hz,
                      ideal: p.ideal,
                      finite: p.finite,
                    }))}
                    logX
                    lines={[
                      {
                        key: 'ideal',
                        name: 'İdeal op-amp',
                        color: '#7795b5',
                        dash: true,
                      },
                      {
                        key: 'finite',
                        name: 'Sonlu bant genişliği',
                        color: '#007f87',
                      },
                    ]}
                  />
                  {nominal && (
                    <div className="lab-metrics">
                      <div>
                        <small>En büyük geçirme sapması</small>
                        <strong>
                          {n(nominal.passDeviation)} <em>dB</em>
                        </strong>
                      </div>
                      <div>
                        <small>En düşük durdurma bastırması</small>
                        <strong>
                          {n(nominal.stopAttenuation)} <em>dB</em>
                        </strong>
                      </div>
                      <div>
                        <small>Nominal hedefler</small>
                        <strong
                          className={
                            nominal.meets ? 'lab-success' : 'lab-caution'
                          }
                        >
                          {nominal.meets ? 'Sağlanıyor' : 'Sağlanmıyor'}
                        </strong>
                      </div>
                    </div>
                  )}
                  <div className="lab-run-row">
                    <div>
                      <h3>1.024 tolerans varyasyonunu karşılaştır.</h3>
                      <p>Aynı R/C sapmaları iki modele de uygulanır.</p>
                    </div>
                    <Button
                      disabled={!valid || !!running}
                      onClick={() => run('audit')}
                    >
                      <Play size={15} />
                      {running === 'audit'
                        ? 'Hesaplanıyor…'
                        : 'Tolerans deneyi'}
                    </Button>
                  </div>
                  {audit && (
                    <div className="lab-result-block">
                      <div className="lab-result-caption">
                        Son tamamlanan deney · {n(audit.specs.passHz, 0)} Hz /{' '}
                        {n(audit.specs.stopHz, 0)} Hz · GBW{' '}
                        {n(audit.opAmp.gbwHz / 1e6)} MHz · tohum{' '}
                        {audit.specs.seed}
                      </div>
                      <div className="lab-metrics">
                        <div>
                          <small>İdeal modelde başarı</small>
                          <strong>%{n(audit.result.idealYieldPct, 1)}</strong>
                        </div>
                        <div>
                          <small>Sonlu modelde başarı</small>
                          <strong>%{n(audit.result.yieldPct, 1)}</strong>
                          <p>
                            %95 aralık: {n(audit.result.yieldCI[0], 1)}–
                            {n(audit.result.yieldCI[1], 1)}
                          </p>
                        </div>
                        <div>
                          <small>İdealde geçen, sonluda kalan</small>
                          <strong>
                            {audit.result.falsePass}
                            <em> / {audit.result.samples}</em>
                          </strong>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        onClick={() =>
                          saveFile(
                            'model-comparison.json',
                            JSON.stringify(audit, null, 2),
                            'application/json',
                          )
                        }
                      >
                        <ArrowDownToLine size={15} />
                        Deney kaydı
                      </Button>
                    </div>
                  )}
                  <details className="lab-details">
                    <summary>Nasıl hesaplanıyor?</summary>
                    <p>
                      Frekans bantlarındaki tüm analitik tepe ve çukur noktaları
                      denetlenir. R ve C sapmaları bağımsız uniform
                      dağılımlıdır. Sonuçlar tek nominal tasarımın
                      varyasyonlarıdır; bütün topolojiler için genellenmez.
                    </p>
                    <p>
                      Tek topolojili bu motor, ngspice 47 ile 12.030 frekans
                      noktasında karşılaştırıldı.{' '}
                      <a href="/research">Doğrulama kayıtları</a>
                    </p>
                  </details>
                </section>
              </TabsContent>
              <TabsContent value="faults">
                <section className="studio-panel lab-card">
                  <div className="lab-card-heading">
                    <div>
                      <div className="eyebrow">02 / EĞİTİLMİŞ SİNİR AĞI</div>
                      <h2>Çıkış yanıtından arızayı tanı.</h2>
                    </div>
                    <BrainCircuit size={30} />
                  </div>
                  <p className="lab-description">
                    Bilinen giriş ve nominal devreye göre, 12 frekanstaki genlik
                    ve faz farkları modele verilir. Etiket, tahmin girdisine
                    dahil değildir.
                  </p>
                  <p className="lab-model-note">
                    Bu bölümün sabit veri modeli: R ±%1, C ±%5; genlikte 0,15 dB
                    ve fazda 1° Gaussian gürültü (standart sapma).
                  </p>
                  <div className="lab-fault-controls">
                    <label htmlFor="fault-select">Enjekte edilen durum</label>
                    <Select
                      value={fault}
                      onValueChange={(v) => {
                        if (v) setFault(v as Fault);
                      }}
                      items={FAULT_NAMES}
                    >
                      <SelectTrigger id="fault-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FAULT_LABELS.map((f) => (
                          <SelectItem key={f} value={f}>
                            {FAULT_NAMES[f]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      onClick={() => setFaultSeed((s) => s + 1)}
                    >
                      <RefreshCw size={15} />
                      Yeni ölçüm
                    </Button>
                  </div>
                  {!faultDomain ? (
                    <p className="lab-error">
                      Arıza modeli eğitim aralığı: R 1–100 kΩ, C 1–100 nF, A₀
                      80–120 dB, GBW 0,1–100 MHz. Referans örneğini seç veya
                      değerleri bu aralığa getir.
                    </p>
                  ) : (
                    <>
                      {sample && (
                        <LabPlot
                          title="Nominal ve arıza eklenmiş ölçüm yanıtı"
                          data={sample.curve.map((p) => ({
                            x: p.hz,
                            nominal: p.nominal,
                            observed: p.observed,
                          }))}
                          logX
                          lines={[
                            {
                              key: 'nominal',
                              name: 'Nominal yanıt',
                              color: '#7795b5',
                              dash: true,
                            },
                            {
                              key: 'observed',
                              name: 'Sentetik ölçüm',
                              color: '#b76e2c',
                            },
                          ]}
                        />
                      )}
                      {diagnosis ? (
                        <div className="fault-diagnosis">
                          <div>
                            <small>MODELİN TAHMİNİ</small>
                            <h3>
                              {diagnosis.predicted
                                ? FAULT_NAMES[diagnosis.predicted]
                                : 'Belirsiz — yeniden ölçüm gerekli'}
                            </h3>
                            <p>
                              Ölçüm tohumu: {faultSeed}
                              {sample?.fault.includes('drift')
                                ? ` · değer çarpanı: ${n(sample.faultFactor)}×`
                                : ''}
                            </p>
                          </div>
                          <div className="fault-scores">
                            {diagnosis.scores.slice(0, 3).map((s) => (
                              <div key={s.label}>
                                <span>{FAULT_NAMES[s.label]}</span>
                                <div>
                                  <i style={{ width: s.score * 100 + '%' }} />
                                </div>
                                <b>%{n(s.score * 100, 1)}</b>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <p>{modelError || 'Model yükleniyor…'}</p>
                      )}
                      {diagnosis && sample && (
                        <Button
                          variant="ghost"
                          onClick={() =>
                            saveFile(
                              'fault-observation.json',
                              JSON.stringify(
                                {
                                  modelVersion: model?.version,
                                  sample,
                                  prediction: diagnosis,
                                  scoreNote:
                                    'Softmax scores, not calibrated probabilities',
                                },
                                null,
                                2,
                              ),
                              'application/json',
                            )
                          }
                        >
                          <ArrowDownToLine size={15} />
                          Ölçüm ve tahmini indir
                        </Button>
                      )}
                    </>
                  )}
                  <div className="lab-test-strip">
                    <div>
                      <strong>%{n(faultReport.test.top1AccuracyPct, 1)}</strong>
                      <span>En yüksek skorlu sınıf doğru</span>
                    </div>
                    <div>
                      <strong>
                        {faultReport.test.falseAlarms}/
                        {faultReport.test.healthySamples}
                      </strong>
                      <span>Sağlıklı testte yanlış alarm</span>
                    </div>
                    <div>
                      <strong>{faultReport.test.uncertain}</strong>
                      <span>Belirsiz bırakılan ölçüm</span>
                    </div>
                  </div>
                  <details className="lab-details">
                    <summary>Test kapsamı ve sınıf matrisi</summary>
                    <p>
                      800 eğitim, 200 doğrulama, 200 test devresi; devre
                      grupları örtüşmüyor. Testte 1.200 sentetik ölçüm var. Altı
                      tekil durum eğitildi. Model skorları kalibre edilmiş
                      olasılıklar değildir; skor 0,60 altında tahmin belirsiz
                      bırakılır. Gerçek donanım ve birden fazla eşzamanlı arıza
                      sınanmadı.
                    </p>
                    <div className="table-scroll">
                      <table>
                        <thead>
                          <tr>
                            <th>Gerçek / tahmin</th>
                            {faultReport.confusionColumns.map((c) => (
                              <th key={c}>
                                {c === 'uncertain'
                                  ? 'Belirsiz'
                                  : FAULT_NAMES[c as Fault]}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {faultReport.confusionMatrix.map((row, i) => (
                            <tr key={i}>
                              <th>{FAULT_NAMES[FAULT_LABELS[i]]}</th>
                              {row.map((v, j) => (
                                <td key={j}>{v}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <a href="/reports/fault-model-report.json" download>
                      Model kartı ve tam sonuçlar
                    </a>
                  </details>
                </section>
              </TabsContent>
              <TabsContent value="budget">
                <section className="studio-panel lab-card">
                  <div className="lab-card-heading">
                    <div>
                      <div className="eyebrow">03 / EŞİT HESAPLAMA BÜTÇESİ</div>
                      <h2>Ayrıntılı simülasyona hangisi değer?</h2>
                    </div>
                    <BrainCircuit size={30} />
                  </div>
                  <p className="lab-description">
                    AI, 8 tolerans çekilişli ön taramadan öğrenir; umut veren
                    veya belirsiz adayları 48 çekilişe yükseltir. Standart GP ve
                    rastgele arama aynı toplam bütçeyi kullanır.
                  </p>
                  <div className="lab-run-row">
                    <div>
                      <label htmlFor="budget-control">
                        Yöntem başına devre değerlendirmesi
                      </label>
                      <Select
                        value={budget}
                        onValueChange={(v) => {
                          if (v) setBudget(v);
                        }}
                        items={{
                          '768': '768 · kısa deney',
                          '1536': '1.536 · standart',
                          '3072': '3.072 · geniş arama',
                        }}
                      >
                        <SelectTrigger id="budget-control" disabled={!!running}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[768, 1536, 3072].map((v) => (
                            <SelectItem key={v} value={String(v)}>
                              {n(v, 0)} değerlendirme
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      disabled={!valid || !!running}
                      onClick={() => run('budget')}
                    >
                      <Play size={15} />
                      Üç yöntemi karşılaştır
                    </Button>
                  </div>
                  <p className="lab-model-note">
                    Arama R 1–100 kΩ, C 1–100 nF uzayındadır. Soldaki referans
                    R/C değerleri başlangıç tasarımı olarak kullanılmaz; filtre
                    hedefi, toleranslar ve op-amp modeli kullanılır.
                  </p>
                  {running === 'budget' && (
                    <div className="lab-progress">
                      <div>
                        <span>{methodNames[progress.method]}</span>
                        <strong>
                          {progress.spent} / {progress.budget}
                        </strong>
                      </div>
                      <progress max={progress.budget} value={progress.spent} />
                      <Button variant="outline" onClick={cancel}>
                        <Square size={13} />
                        Durdur
                      </Button>
                    </div>
                  )}
                  {experiment && (
                    <>
                      <div className="lab-result-caption">
                        Son tamamlanan deney · {n(experiment.specs.passHz, 0)}{' '}
                        Hz / {n(experiment.specs.stopHz, 0)} Hz · GBW{' '}
                        {n(experiment.opAmp.gbwHz / 1e6)} MHz · tohum{' '}
                        {experiment.specs.seed}
                      </div>
                      <LabPlot
                        title="Eşit simülasyon bütçesinde en iyi eğitim ihlali"
                        data={budgetCurves}
                        xLabel="Devre değerlendirmesi"
                        yLabel="asinh(skor) · düşük daha iyi"
                        lines={experiment.methods.map((m) => ({
                          key: m.method,
                          name: methodNames[m.method],
                          color: methodColors[m.method],
                          dash: m.method !== 'adaptive',
                        }))}
                      />
                      <div className="budget-results">
                        {experiment.methods.map((m) => (
                          <article key={m.method}>
                            <span
                              className="budget-method"
                              style={{ color: methodColors[m.method] }}
                            >
                              {methodNames[m.method]}
                            </span>
                            <h3>%{n(m.audit.yieldPct, 1)}</h3>
                            <p>Bağımsız tolerans verimi</p>
                            <small>
                              %95 aralık: {n(m.audit.yieldCI[0], 1)}–
                              {n(m.audit.yieldCI[1], 1)}
                            </small>
                            <dl>
                              <div>
                                <dt>Ayrıntılı aday</dt>
                                <dd>{m.fullEvaluations}</dd>
                              </div>
                              <div>
                                <dt>Ön tarama</dt>
                                <dd>{m.screens}</dd>
                              </div>
                              <div>
                                <dt>Harcanan bütçe</dt>
                                <dd>{m.spent}</dd>
                              </div>
                              <div>
                                <dt>Arama süresi</dt>
                                <dd>{n(m.elapsedMs / 1000)} sn</dd>
                              </div>
                            </dl>
                            <Button
                              variant="outline"
                              onClick={() => {
                                setFields((f) => ({
                                  ...f,
                                  r1: String(m.winner.r1 / 1000),
                                  r2: String(m.winner.r2 / 1000),
                                  c1: String(m.winner.c1 / 1e-9),
                                  c2: String(m.winner.c2 / 1e-9),
                                  passHz: String(experiment.specs.passHz),
                                  stopHz: String(experiment.specs.stopHz),
                                  rippleDb: String(experiment.specs.rippleDb),
                                  stopDb: String(experiment.specs.stopDb),
                                  rTol: String(experiment.specs.rTol),
                                  cTol: String(experiment.specs.cTol),
                                  a0Db: String(experiment.opAmp.a0Db),
                                  gbwMHz: String(experiment.opAmp.gbwHz / 1e6),
                                  seed: String(experiment.specs.seed),
                                }));
                                setTab('models');
                              }}
                            >
                              Devreyi incele <ChevronRight size={14} />
                            </Button>
                          </article>
                        ))}
                      </div>
                      <Button
                        variant="ghost"
                        onClick={() =>
                          saveFile(
                            'adaptive-search.json',
                            JSON.stringify(experiment, null, 2),
                            'application/json',
                          )
                        }
                      >
                        <ArrowDownToLine size={15} />
                        Tüm denemeleri indir
                      </Button>
                    </>
                  )}
                  <details className="lab-details">
                    <summary>Adil karşılaştırmanın kuralları</summary>
                    <p>
                      8 ortak başlangıç devresi, ortak 48 eğitim toleransı ve
                      eşit oracle bütçesi. Ön tarama 8, yükseltme 40 yeni
                      değerlendirme harcar; önceki 8 sonuç önbellekten
                      kullanılır. GP tahmini beklenen iyileşmeye göre ayrıntılı
                      aday seçer. Yalnız 48 çekilişle değerlendirilen adaylar
                      kazanabilir.
                    </p>
                    <p>
                      Kazananlar eğitim skoruyla sabitlenir; sonra yöntem başına
                      1.024 yeni çekiliş uygulanır. Bu 3.072 son test
                      değerlendirmesi arama bütçesinin dışındadır. GP hesaplama
                      süresi de süre ölçümündedir. Tek deney üstünlük kanıtı
                      değildir; her yöntemin sonucu korunur.
                    </p>
                  </details>
                </section>
              </TabsContent>
              <TabsContent value="signal">
                <section className="studio-panel lab-card">
                  <div className="lab-card-heading">
                    <div>
                      <div className="eyebrow">04 / SANAL SENSÖR DENEYİ</div>
                      <h2>Gürültüyü azaltırken sinyali koru.</h2>
                    </div>
                    <AudioWaveform size={30} />
                  </div>
                  <p className="lab-description">
                    12 Hz faydalı ivme sinyaline titreşim eklenir; analog
                    filtrenin çıkışı örneklenir. Soldaki “Sensör filtresi”
                    örneğiyle başlayabilirsin.
                  </p>
                  <div className="signal-controls">
                    {[
                      {
                        label: 'Örnekleme',
                        value: sampleHz,
                        min: 100,
                        max: 1000,
                        step: 10,
                        unit: 'Hz',
                        set: setSampleHz,
                      },
                      {
                        label: 'Titreşim frekansı',
                        value: vibrationHz,
                        min: 100,
                        max: 2000,
                        step: 10,
                        unit: 'Hz',
                        set: setVibrationHz,
                      },
                      {
                        label: 'Titreşim genliği',
                        value: amplitude,
                        min: 0.05,
                        max: 0.8,
                        step: 0.05,
                        unit: 'g',
                        set: setAmplitude,
                      },
                    ].map((c) => (
                      <div key={c.label}>
                        <label>
                          {c.label}{' '}
                          <strong>
                            {n(c.value)} {c.unit}
                          </strong>
                        </label>
                        <Slider
                          aria-label={c.label}
                          min={c.min}
                          max={c.max}
                          step={c.step}
                          value={[c.value]}
                          onValueChange={(v) =>
                            c.set(Array.isArray(v) ? v[0] : v)
                          }
                        />
                      </div>
                    ))}
                  </div>
                  {signal && (
                    <>
                      <LabPlot
                        title="Sentetik ivme sinyali ve analog filtreden sonra örneklenen yanıt"
                        data={signal.points}
                        xLabel="ms"
                        yLabel="g"
                        lines={[
                          { key: 'raw', name: 'Ham ölçüm', color: '#c8a477' },
                          {
                            key: 'clean',
                            name: 'İstenen sinyal',
                            color: '#738cab',
                            dash: true,
                          },
                          {
                            key: 'filtered',
                            name: 'Filtreli ölçüm',
                            color: '#007f87',
                          },
                        ]}
                      />
                      <div className="lab-metrics">
                        <div>
                          <small>Ham → filtreli RMS hata</small>
                          <strong>
                            {n(signal.rawRmse, 3)} → {n(signal.filteredRmse, 3)}
                            <em> g</em>
                          </strong>
                        </div>
                        <div>
                          <small>Titreşim bastırması</small>
                          <strong>
                            {n(signal.vibrationAttenuationDb)}
                            <em> dB</em>
                          </strong>
                        </div>
                        <div>
                          <small>12 Hz faz gecikmesi</small>
                          <strong>
                            {n(signal.phaseDelayMs)}
                            <em> ms</em>
                          </strong>
                        </div>
                      </div>
                      <p className="lab-alias-note">
                        {vibrationHz >= sampleHz / 2
                          ? `${n(vibrationHz, 0)} Hz titreşim örnekleme sonrasında ${n(signal.aliasHz, 0)} Hz gibi görünür. Analog filtre örnekleme öncesinde bastırmayı sağlar.`
                          : 'Titreşim frekansı Nyquist sınırının altında.'}
                      </p>
                      <Button
                        variant="ghost"
                        onClick={() =>
                          saveFile(
                            'sensor-signal.json',
                            JSON.stringify(
                              { parts, opAmp, ...signal },
                              null,
                              2,
                            ),
                            'application/json',
                          )
                        }
                      >
                        <ArrowDownToLine size={15} />
                        Sinyal verisini indir
                      </Button>
                    </>
                  )}
                  <details className="lab-details">
                    <summary>Deney varsayımları</summary>
                    <p>
                      İki sinüsün doğrusal, kararlı durum yanıtıdır. Gerçek uçuş
                      kaydı, geçici rejim veya ADC kuantalaması değildir. RMS
                      hata, temiz sinyale zaman kaydırması uygulanmadan ölçülür;
                      gecikme ve sinyal bozulması da hataya dahildir.
                    </p>
                  </details>
                </section>
              </TabsContent>
            </Tabs>
            {error && (
              <p className="lab-error" role="alert">
                {error}
              </p>
            )}
          </div>
        </div>
        <footer className="studio-footer">
          <span>Hesaplama cihazında çalışır · sonuçları JSON olarak indir</span>
          <a href="/research">
            Yöntem ve doğrulama <ArrowUpRight size={14} />
          </a>
          <a href="/">
            <ArrowLeft size={14} />
            Kart Studio
          </a>
        </footer>
      </main>
    </div>
  );
}
